from django.apps import AppConfig


class ImageFileTestConfig(AppConfig):
    name = 'image_file_test'
