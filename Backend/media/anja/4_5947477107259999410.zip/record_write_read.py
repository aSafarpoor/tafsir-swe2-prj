#!/usr/bin/env python3
from scipy.io import wavfile as wav
import pyaudio
import wave
import matplotlib.pyplot as plt
from scipy.fftpack import fft
import numpy as np
from matplotlib.pyplot import figure


FORMAT = pyaudio.paInt16  # format of sampling 16 bit int
CHANNELS = 1  # number of channels it means number of sample in every sampling
RATE = 44100  # number of sample in 1 second sampling
CHUNK = 1024  # length of every chunk
RECORD_SECONDS = 1  # time of recording in seconds
WAVE_OUTPUT_FILENAME = "file.wav"  # file name



inputt = "y"
while(inputt == "y"):
    audio = pyaudio.PyAudio()

    # start Recording
    stream = audio.open(format=FORMAT, channels=CHANNELS,
                        rate=RATE, input=True,
                        frames_per_buffer=CHUNK)
    print("recording...")
    frames = []

    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        decode = np.frombuffer(data, dtype=np.int16)
        for x in decode:
            frames.append(x)
    print("finished recording")
    # stop Recording
    stream.stop_stream()
    stream.close()
    audio.terminate()

    # storing voice
    waveFile = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    waveFile.setnchannels(CHANNELS)
    waveFile.setsampwidth(audio.get_sample_size(FORMAT))
    waveFile.setframerate(RATE)
    waveFile.writeframes(b''.join(frames))
    waveFile.close()

    # reading voice
    rate, data = wav.read('file.wav')
    # data is voice signal. its type is list(or numpy array)
    x_fft = np.linspace(0, RATE, CHUNK)
    # plt.plot(np.abs(fft(np.sin(2*x_fft))))
    # plt.show()
    frames_fft = fft(frames)
    fft_array = []
    index = []
    j = 0
    for i in frames_fft:
        fft_array.append(abs(i))
        index.append(j)
        j += 1
    # print(fft_array)

    r = 1750
    r1 = 0
    figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
    X = index[r1:r]
    Y = fft_array[r1:r]

    plt.plot(X, Y)
    plt.show()

    Y1 = Y[600:1050]
    Y2 = Y[1080:1750]
    # temp.sort()
    first_peak = 0
    second_peak = 0
    for i in range(0, len(Y1)):
        if (Y1[i] > Y1[first_peak]):
            first_peak = i
    # print(len(Y))
    # Y = Y[0:first_peak] + Y[first_peak +1:]
    # print(len(Y))
    for i in range(0, len(Y2)):
        if ((Y2[i] > Y2[second_peak]) and i != first_peak):
            second_peak = i
    first_peak += 600
    second_peak += 1080

    # print("first peak")
    # print(first_peak)
    # print("second peak")
    # print(second_peak)
    tolerance = 50

    row = 0
    column = 0
    i_ = [1209, 1336, 1477, 1633]
    j_ = [697, 770, 852, 941]

    for i in i_:
        if ((second_peak >= i - tolerance) and (second_peak <= i + tolerance)):
            column = i
    for j in j_:
        if ((first_peak >= j - tolerance) and (first_peak <= j + tolerance)):
            row = j
    a = (row, column)
    dic = {(697, 1209): '1', (697, 1336): '2', (697, 1477): '3', (697, 1633): 'A',
           (770, 1209): '4', (770, 1336): '5', (770, 1477): '6', (770, 1633): 'B',
           (852, 1209): '7', (852, 1336): '8', (852, 1477): '9', (852, 1633): 'C',
           (941, 1209): '*', (941, 1336): '0', (941, 1477): '#', (941, 1633): 'D'}
    out = ''
    try:
        out = dic[a]
        print(out)
    except:
        print("wrong input!")
    inputt = ""
    print("Do you want to continue?"
          "press \'y\' for yes"
          "and any thing for not!!!")
    inputt = input()

